# 堅棟堅企 V12

- 開啟 App 時水印日期自動更新為今天。
- 其他設定使用 SharedPreferences 保存並於下次開啟恢復。
- 移除「今日工作模式」按鈕。
- 使用提供的新圖片作為 App icon。
- Codemagic 會建立全新 Android 專案，避免 Android v1 embedding。
